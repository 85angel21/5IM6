package calculadora;

public class Calculadora {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Cancula calculadora = new Cancula();
        calculadora.setVisible(true);
    }

}
